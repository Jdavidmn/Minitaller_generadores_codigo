//
// Classroom License -- for classroom instructional use only.  Not for
// government, commercial, academic research, or other organizational use.
//
// fibonacci_series_initialize.cpp
//
// Code generation for function 'fibonacci_series_initialize'
//

// Include files
#include "fibonacci_series_initialize.h"

// Function Definitions
void fibonacci_series_initialize()
{
}

// End of code generation (fibonacci_series_initialize.cpp)
