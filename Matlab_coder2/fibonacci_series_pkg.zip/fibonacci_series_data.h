//
// Classroom License -- for classroom instructional use only.  Not for
// government, commercial, academic research, or other organizational use.
//
// fibonacci_series_data.h
//
// Code generation for function 'fibonacci_series_data'
//

#ifndef FIBONACCI_SERIES_DATA_H
#define FIBONACCI_SERIES_DATA_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

#endif
// End of code generation (fibonacci_series_data.h)
