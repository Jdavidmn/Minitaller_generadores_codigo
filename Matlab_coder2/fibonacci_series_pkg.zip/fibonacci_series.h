//
// Classroom License -- for classroom instructional use only.  Not for
// government, commercial, academic research, or other organizational use.
//
// fibonacci_series.h
//
// Code generation for function 'fibonacci_series'
//

#ifndef FIBONACCI_SERIES_H
#define FIBONACCI_SERIES_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void fibonacci_series(double n, coder::array<double, 2U> &fib_values);

#endif
// End of code generation (fibonacci_series.h)
