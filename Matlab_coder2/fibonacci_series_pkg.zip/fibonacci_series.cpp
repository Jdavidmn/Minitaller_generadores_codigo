//
// Classroom License -- for classroom instructional use only.  Not for
// government, commercial, academic research, or other organizational use.
//
// fibonacci_series.cpp
//
// Code generation for function 'fibonacci_series'
//

// Include files
#include "fibonacci_series.h"
#include "coder_array.h"

// Function Definitions
void fibonacci_series(double n, coder::array<double, 2U> &fib_values)
{
  int i;
  int loop_ub_tmp;
  loop_ub_tmp = static_cast<int>(n);
  fib_values.set_size(1, loop_ub_tmp);
  for (i = 0; i < loop_ub_tmp; i++) {
    fib_values[i] = 0.0;
  }
  fib_values[1] = 1.0;
  i = static_cast<int>(n + -2.0);
  for (loop_ub_tmp = 0; loop_ub_tmp < i; loop_ub_tmp++) {
    fib_values[loop_ub_tmp + 2] =
        fib_values[loop_ub_tmp + 1] + fib_values[loop_ub_tmp];
  }
}

// End of code generation (fibonacci_series.cpp)
