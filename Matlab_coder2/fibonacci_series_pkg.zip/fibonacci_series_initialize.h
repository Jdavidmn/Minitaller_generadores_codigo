//
// Classroom License -- for classroom instructional use only.  Not for
// government, commercial, academic research, or other organizational use.
//
// fibonacci_series_initialize.h
//
// Code generation for function 'fibonacci_series_initialize'
//

#ifndef FIBONACCI_SERIES_INITIALIZE_H
#define FIBONACCI_SERIES_INITIALIZE_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void fibonacci_series_initialize();

#endif
// End of code generation (fibonacci_series_initialize.h)
