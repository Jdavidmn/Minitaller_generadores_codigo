//
// Classroom License -- for classroom instructional use only.  Not for
// government, commercial, academic research, or other organizational use.
//
// fibonacci_series_types.h
//
// Code generation for function 'fibonacci_series'
//

#ifndef FIBONACCI_SERIES_TYPES_H
#define FIBONACCI_SERIES_TYPES_H

// Include files
#include "rtwtypes.h"

#endif
// End of code generation (fibonacci_series_types.h)
